/**
 * 
 */
package de.uni_koeln.ai.student.mazey.binger.gui.java;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.util.List;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

import de.uni_koeln.ai.student.mazey.binger.conncetor.java.Connecter;
import de.uni_koeln.ai.student.mazey.utils.java.Downloader;
import de.uni_koeln.ai.student.mazey.utils.java.Splitter;

/**
 * @author mazey
 *
 */
public class Shell extends org.eclipse.swt.widgets.Shell implements Runnable {

	private Connecter connecter = new Connecter();
	private Splitter splitter = new Splitter();
	private Downloader downloader = new Downloader();

	private Text links;
	private Text valKey;
	private Text dir;
	private Text query;

	public Shell() {

	}

	/**
	 * Launch the application.
	 * 
	 * @param args
	 * @return
	 */
	public void run() {
		try {
			Display display = Display.getDefault();
			Shell shell = new Shell(display);
			shell.open();
			shell.layout();
			while (!shell.isDisposed()) {
				if (!display.readAndDispatch()) {
					display.sleep();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public Shell(final Display display) {
		super(display, SWT.SHELL_TRIM);

		links = new Text(this, SWT.BORDER | SWT.READ_ONLY | SWT.H_SCROLL | SWT.V_SCROLL | SWT.CANCEL);
		links.setBounds(10, 119, 580, 219);

		Button download = new Button(this, SWT.NONE);
		download.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent arg0) {

				display.syncExec(new Thread(new Runnable() {

					public void run() {
						
						String result = null;
						String vali = valKey.getText().replace(" ", "");
						String q = query.getText().replace(" ", "_");
						String directory = dir.getText();
						
						int loop = 10;
						int off = 150;

						for (int i = 0; i < loop; i++) {
							int offSet = i * off;
							result = connecter.requestBingImages(vali,
									q, off, offSet);
						}

						List<String> json = splitter.extractContent(result);

						for (String currentLink : json) {
							links.setText(downloader.download(currentLink, directory));
						}

					}
				}));
			}
		});

		download.setBounds(10, 85, 160, 28);
		download.setText("Download");

		Button shwDir = new Button(this, SWT.NONE);
		shwDir.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent arg0) {

				display.syncExec(new Runnable() {

					public void run() {
						if (!new File(dir.getText()).exists()) {
							links.setText("Directory does not exist");
						} else {
							Desktop desktop = Desktop.getDesktop();
							try {
								desktop.open(new File(dir.getText()));
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
					}
				});
			}
		});
		
		shwDir.setBounds(220, 85, 160, 28);
		shwDir.setText("Directory");

		Button cancel = new Button(this, SWT.NONE);
		cancel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent arg0) {

				// TODO implement cancel download

			}
		});
		cancel.setBounds(430, 85, 160, 28);
		cancel.setText("Cancel");

		valKey = new Text(this, SWT.BORDER);
		valKey.setBounds(220, 10, 370, 19);

		Label lblValidationKey = new Label(this, SWT.NONE);
		lblValidationKey.setBounds(10, 13, 114, 14);
		lblValidationKey.setText("Validation Key:");

		query = new Text(this, SWT.BORDER);
		query.setBounds(220, 60, 370, 19);

		Label lblNewLabel = new Label(this, SWT.NONE);
		lblNewLabel.setBounds(10, 38, 59, 14);
		lblNewLabel.setText("Directory:");

		dir = new Text(this, SWT.BORDER);
		dir.setBounds(220, 35, 370, 19);

		Label lblQuery = new Label(this, SWT.NONE);
		lblQuery.setText("Query:");
		lblQuery.setBounds(10, 63, 59, 14);
		createContents();
	}

	/**
	 * Create contents of the shell.
	 */
	protected void createContents() {
		setText("Binger");
		setSize(600, 370);
	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}

}
