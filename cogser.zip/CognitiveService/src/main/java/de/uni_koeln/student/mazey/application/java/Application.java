/**
 * 
 */
package de.uni_koeln.student.mazey.application.java;

import java.io.IOException;
import java.util.List;

import de.uni_koeln.student.mazey.bingconnecter.java.Connecter;
import de.uni_koeln.student.mazey.utils.java.Downloader;
import de.uni_koeln.student.mazey.utils.java.Splitter;

/**
 * @author mazey
 *
 */
public class Application {

	public static void main(String[] args) throws IOException {
		
		String query = "female+bust";
		String name = query.replaceAll("[+]", "_");
		String regEx = "\"contentUrl\": \"";
		String directory = "/Users/christophalexander/OneDrive/UNI/wieners_imageRecognition/imageData/"+ name + "/";
		
		int off = 150;
		int loop = 10;
		
		List<String> content = null;
		Splitter splitter = new Splitter();
		Downloader downloader = new Downloader();
		
		for(int i=0; i<loop; i++){
			int offSet = i * off;			
			downloader.download(content = splitter.extractContent(
					new Connecter().requestBingImages(query, off, offSet), regEx), 
					directory);
			
		}
		
		downloader.saveImageStore(directory + "imageStore_" + name + ".txt");
		
	}
	
}
