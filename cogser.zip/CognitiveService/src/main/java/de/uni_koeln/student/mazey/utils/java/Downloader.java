package de.uni_koeln.student.mazey.utils.java;
/**
 * 
 */


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jsoup.Connection.Response;
import org.jsoup.Jsoup;

/**
 * Class is used to Download images via link.
 * 
 * @author mazey
 *
 */
public class Downloader {

	private static final String USER_AGENT = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.112 Safari/535.1";
	
	private Map<String, Integer> imageStore = new HashMap<String, Integer>();

	/**
	 * Class downloads images via links that are stored in a list.
	 * </p>
	 * In order to download a file, the method loops through the list of
	 * links</br>
	 * and checks whether they are <b>null</b> nor not. In case an element is
	 * null</br>
	 * the method skips this element and continues with the next.
	 * </p>
	 * 
	 * @param links
	 *            List<String> links that contain links.
	 * @param directory
	 *            Name of the folder where the image will be stored.
	 * @throws IOException
	 *             MalformedURLException
	 */

	public void download(List<String> links, String directory) throws IOException {
		// TODO: CREATE DOWNLOADER

		File dir = new File(directory);

		if (dir.exists()) {

			for (int i = 0; i < links.size(); i++) {
				if (links.get(i) == null) {
					String link = links.get(i);
					String nextLink = links.get(i + 1);
					link = nextLink;
					loadImage(link, directory, i);
				} else {
					String link = links.get(i);
					loadImage(link, directory, i);
				}
			}

		} else {
			System.out.println("*** Directory does not exist ***");
			return;
		}

	}

	private void loadImage(String link, String directory, int i) {

		try {
			/*
			 * Creates response from link
			 * userAgent is used to fake a user (reference in Spider.java)
			 * ignoreContentType is responsible for parsing the HTML document regardless its type
			 * execute() executes the request in order to get a response
			 * bodyAsBytes creates a byte[] that contains the bytes of the image in the end
			 */
			Response response = Jsoup.connect(link).userAgent(USER_AGENT).ignoreContentType(true).execute();

			System.out.println("Download:\t" + link);
			
			int hash = link.hashCode();
			imageStore.put(link, hash);
			
			String path = directory + "img" + hash + ".jpg";

			FileOutputStream fos = (new FileOutputStream(new File(path)));
			fos.write(response.bodyAsBytes()); 
			fos.close();

		} catch (IllegalArgumentException e) {
			System.out.println(e);
		} catch (FileNotFoundException e) {
			System.out.println(e);
		} catch (IOException e) {
			System.out.println(e);
		}

	}
	
	public void saveImageStore(String fileName) {
		PrintWriter pw;
		try {
			pw = new PrintWriter(fileName);
			pw.println(imageStore.toString());
			pw.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
}
