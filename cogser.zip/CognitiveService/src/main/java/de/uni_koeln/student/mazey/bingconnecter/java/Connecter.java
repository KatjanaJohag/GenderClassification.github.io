package de.uni_koeln.student.mazey.bingconnecter.java;

import java.net.URI;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

/**
 * Connects to Bing.
 * 
 * @author mazey
 *
 */
public class Connecter {

	/**
	 * This method sends a request to Bing image search which then sends return the </br>
	 * result as string.</p> 
	 * @param query
	 * @param numberOfResults
	 */
	
	public String requestBingImages(String query, int numberOfResults, int offSet) {
		
		String result = null;
		String link = "https://api.cognitive.microsoft.com/bing/v5.0/images/search?q=" +
					query + "&count=" + numberOfResults +
					"&offset=" + offSet + "&mkt=en-us&safeSearch=Moderate";
		HttpClient httpclient = HttpClients.createDefault();
		
		try {
			
			URIBuilder builder = new URIBuilder(link);
			
			URI uri = builder.build();
			/*
			 * I know, we won't post anything on bing but there is,
			 * as far as I can see, no other way to request the body of 
			 * search result.
			 * HttpGet.java does not offer .setEntity(), therefore, 
			 * I'd suggest an OutPutStream ... I'll try this later.
			 * In case one of you has a solution please let me know.
			 */
			HttpGet get = new HttpGet(uri);
			//HttpPost post = new HttpPost(uri);
			get.setHeader(	"Ocp-Apim-Subscription-Key", 
							"77391d38c0e6494da0dbdda7b36465d9");
			
			//Get body of Search
			//StringEntity entity = new StringEntity("{body}");
			//post.setEntity(entity);
			
			HttpResponse response = httpclient.execute(get);
			HttpEntity httpEntity = response.getEntity();
			
			result = EntityUtils.toString(httpEntity);
			System.out.println(result);
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return result;		
	}
	
}
