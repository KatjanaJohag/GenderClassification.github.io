/**
 * 
 */
package de.uni_koeln.ai.student.mazey.utils.java;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author mazey
 *
 */
public class Splitter {

public List<String> extractContent(String result) {
		
		String regEx = "\"contentUrl\": \"";
		List<String> imageContent = new ArrayList<String>();
		List<String> tmpContent = Arrays.asList(result.split(regEx));
		
		for (String link : tmpContent) {
			int endIndex = link.indexOf("\",");
			link = link.substring(0, endIndex);
			link = link.replace("\\", "");
			imageContent.add(link);
		}
		
		return imageContent;
	}
	
}
