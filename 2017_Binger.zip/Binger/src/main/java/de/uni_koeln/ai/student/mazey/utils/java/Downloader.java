/**
 * 
 */
package de.uni_koeln.ai.student.mazey.utils.java;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.jsoup.Connection.Response;
import org.jsoup.Jsoup;

/**
 * @author mazey
 *
 */
public class Downloader {

	private static final String USER_AGENT = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.112 Safari/535.1";
	
	public String download(String link, String directory) {
		File dir = new File(directory);
		if (dir.exists()) {
			link = loadImage(link, directory);
		} else {
			link = "*** Directory does not exist ***";
		}
		return link;
	}
	
	private String loadImage(String link, String directory) {
	
		try {
			Response response = Jsoup.connect(link).userAgent(USER_AGENT).ignoreContentType(true).execute();
			String path = directory + "img" + link.hashCode() + ".jpg";
			
			FileOutputStream fos = (new FileOutputStream(new File(path)));
			fos.write(response.bodyAsBytes()); 
			fos.close();
			
		} catch (IllegalArgumentException e) {
			System.out.println(e);
		} catch (FileNotFoundException e) {
			System.out.println(e);
		} catch (IOException e) {
			System.out.println(e);
		}
		
		return link;
	}
	
}
