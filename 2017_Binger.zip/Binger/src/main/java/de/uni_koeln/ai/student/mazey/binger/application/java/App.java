package de.uni_koeln.ai.student.mazey.binger.application.java;

import de.uni_koeln.ai.student.mazey.binger.gui.java.Shell;

/**
 * @author mazey
 *
 */
public class App {

	public static void main(String[] args) {
		Shell shell = new Shell();
		shell.run();
	}
	
}
