package de.uni_koeln.ai.student.mazey.binger.conncetor.java;

import java.net.URI;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

/**
 * Connects to Bing.
 * 
 * @author mazey
 *
 */
public class Connecter {

	/**
	 * This method sends a request to Bing image search which then sends return the </br>
	 * result as string.</p> 
	 * 
	 * @param  validationKey
	 * @param  query
	 * @param  resultNumber
	 * @param  offSet
	 * @return JSON Body
	 */
	
	public String requestBingImages(String validationKey, String query, int resultNumber, int offSet) {
		
		String result = null;
		
		String link = "https://api.cognitive.microsoft.com/bing/v5.0/images/search?q=" +
					query + "&count=" + resultNumber +
					"&offset=" + offSet + "&mkt=en-us&safeSearch=Moderate";
		HttpClient httpclient = HttpClients.createDefault();
		
		try {
			
			URIBuilder builder = new URIBuilder(link);
			
			URI uri = builder.build();
			HttpGet get = new HttpGet(uri);
			get.setHeader(	"Ocp-Apim-Subscription-Key", 
							validationKey);
			
			HttpResponse response = httpclient.execute(get);
			HttpEntity httpEntity = response.getEntity();
			
			result = EntityUtils.toString(httpEntity);
			System.out.println(result);
			get.completed();
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return result;		
	}
	
}
